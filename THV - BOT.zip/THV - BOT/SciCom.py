from config import MONGO_URI, PDF_DIR, CITATION_DIR
from db_utils import connect_to_mongo, init_db, get_keywords, get_last_successful_run_date
from pubmed_utils import search_pubmed_date_range, fetch_pubmed_details
from pdf_utils import attempt_pdf_download
from abbrev_utils import get_abbreviation_map, compute_updated_title
from utils import sanitize_filename, generate_citation
from pdf_text_utils import extract_pdf_text
from tag_utils import suggest_tags

import os
from datetime import datetime, timedelta
import concurrent.futures

# -------------------- Main Extraction Logic --------------------

def run_extraction(use_parallel=False):
    """
    Automated extraction process that:
      1) Initializes DB & loads new keywords/abbreviations.
      2) Determines date range (last successful run vs 30 days).
      3) For each keyword, fetches PubMed IDs and processes them.
      4) Collects citations for Paid articles in a single list (paid_citations), 
         avoiding duplicates by tracking paid_ids_seen.
      5) AFTER all keywords, writes one set of text files to 'citations' folder,
         each file holding up to 50 citations.
    """

    db = init_db()
    keywords = get_keywords(db)
    if not keywords:
        print("No keywords found in the database. Exiting extraction.")
        return

    abbr_map = get_abbreviation_map(db)

    # Create a run log entry
    start_time = datetime.now()
    run_log = {
        "start_time": start_time,
        "status": "started",
        "keywords": keywords,
        "articles_processed": 0,
        "errors": []
    }
    run_log_id = db["run_logs"].insert_one(run_log).inserted_id
    print(f"Run started at {start_time}")

    try:
        # Determine date range
        last_successful = get_last_successful_run_date(db)
        if last_successful is None:
            start_date = datetime.now() - timedelta(days=30)
        else:
            start_date = last_successful
        end_date = datetime.now()

        total_articles_processed = 0

        # ONE list for ALL paid citations across all keywords
        paid_citations = []
        # A set of PubMed IDs so we don't add duplicate citations
        paid_ids_seen = set()

        # Loop over each keyword just once
        for keyword in keywords:
            print(f"\n🔍 Processing keyword: {keyword}")
            pubmed_ids = search_pubmed_date_range(keyword, start_date, end_date)

            if pubmed_ids:
                print(f"➡️ Found {len(pubmed_ids)} articles for '{keyword}'")
            else:
                print(f"❌ No new articles found for keyword '{keyword}'")
                continue



            # Parallel or serial
            if use_parallel:
                with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                    futures = []
                    for pid in pubmed_ids:
                        futures.append(executor.submit(
                            process_pubmed_id, pid, db, abbr_map, run_log_id
                        ))
                    for future in concurrent.futures.as_completed(futures):
                        result = future.result()
                        if result and not result.get("skipped"):
                            total_articles_processed += 1
                            if result.get("access") == "Paid":
                                # Avoid duplicates
                                if result["pubmed_id"] not in paid_ids_seen:
                                    doc = db["articles"].find_one({"pubmed_id": result["pubmed_id"]})
                                    if doc:
                                        citation = generate_citation(doc)
                                        paid_citations.append(citation)
                                    paid_ids_seen.add(result["pubmed_id"])
            else:
                # Serial approach
                for pid in pubmed_ids:
                    result = process_pubmed_id(pid, db, abbr_map, run_log_id)
                    if result and not result.get("skipped"):
                        total_articles_processed += 1
                        if result.get("access") == "Paid":
                            # Avoid duplicates
                            if pid not in paid_ids_seen:
                                doc = db["articles"].find_one({"pubmed_id": pid})
                                if doc:
                                    citation = generate_citation(doc)
                                    paid_citations.append(citation)
                                paid_ids_seen.add(pid)

            # ✅ SAVE CITATIONS PER KEYWORD (in chunks of 50)
            if paid_citations:
                os.makedirs(CITATION_DIR, exist_ok=True)
                date_str = datetime.now().strftime("%Y-%m-%d")
                keyword_sanitized = keyword.replace(" ", "_").lower()

                num_files = (len(paid_citations) + 49) // 50
                for i in range(num_files):
                    chunk = paid_citations[i*50 : (i+1)*50]
                    citation_text = "\n\n".join(chunk)
                    file_path = os.path.join(
                        CITATION_DIR,
                        f"{keyword_sanitized}_{date_str}_{i+1}.txt"
                    )
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(citation_text)
                    print(f"✅ Saved {len(chunk)} citations for '{keyword}' to {file_path}")
            else:
                print(f"⚠️ No paid articles found for keyword: {keyword}")

        # Mark the run as complete
        end_time = datetime.now()
        db["run_logs"].update_one(
            {"_id": run_log_id},
            {"$set": {
                "end_time": end_time,
                "status": "completed",
                "articles_processed": total_articles_processed
            }}
        )
        print(f"Extraction run completed at {end_time}. Total articles processed: {total_articles_processed}")

    except Exception as e:
        # If any error occurs, update the run log accordingly
        end_time = datetime.now()
        db["run_logs"].update_one(
            {"_id": run_log_id},
            {"$set": {
                "end_time": end_time,
                "status": "error",
                "error": str(e)
            }}
        )
        print(f"Extraction run encountered an error at {end_time}: {e}")

def process_pubmed_id(pid, db, abbr_map, run_log_id):
    """
    1) Always fetch metadata first.
    2) Check if article already exists.
    3) Compute or reuse updated_title.
    4) Check if correct PDF already exists.
    5) If not, attempt download via PMC.
    6) Extract text & store in article_text collection.
    7) Generate suggested_tags + approved_tags.
    8) Insert/update into articles collection.
    """
    # ✅ Always fetch metadata FIRST
    details = fetch_pubmed_details(pid)
    if "error" in details:
        db["run_logs"].update_one(
            {"_id": run_log_id},
            {"$push": {
                "errors": {
                    "pubmed_id": pid,
                    "error": details["error"],
                    "timestamp": datetime.now()
                }
            }}
        )
        return {"pubmed_id": pid, "error": details["error"]}

    # ✅ Check if article already exists
    existing_doc = db["articles"].find_one({"pubmed_id": pid})

    # ✅ Compute updated_title
    if existing_doc and "updated_title" in existing_doc:
        updated_title = existing_doc["updated_title"]
    else:
        updated_title = compute_updated_title(details, abbr_map)
    details["updated_title"] = updated_title

    # ✅ Generate consistent filename
    new_pdf_filename = sanitize_filename(updated_title) + ".pdf"
    local_pdf_path = os.path.join(PDF_DIR, new_pdf_filename)

    # ✅ Check if correct PDF already exists
    if os.path.exists(local_pdf_path):
        print(f"✅ PDF already exists for PubMed ID {pid}: {new_pdf_filename}")
        pdf_file = local_pdf_path
    else:
        pdf_file = attempt_pdf_download(details, new_filename=new_pdf_filename)

    # ✅ Extract text
    full_text = ""
    if pdf_file and os.path.exists(pdf_file):
        full_text = extract_pdf_text(pdf_file)

    db["article_text"].update_one(
        {"pubmed_id": pid},
        {"$set": {"full_text": full_text}},
        upsert=True
    )

    # ✅ Save file path or null
    details["pdf_file"] = pdf_file if pdf_file else None

    # ✅ Tagging
    tag_source = " ".join([
        details.get("title", ""),
        details.get("abstract", ""),
        full_text
    ])
    details["suggested_tags"] = suggest_tags(tag_source, top_k=10)
    details["approved_tags"] = []

    # ✅ Webscraped timestamp
    details["webscraped_date"] = datetime.now().strftime("%Y-%m-%d")

    # ✅ Insert or update
    if existing_doc:
        db["articles"].update_one({"_id": existing_doc["_id"]}, {"$set": details})
    else:
        db["articles"].insert_one(details)

    return {
        "pubmed_id": pid,
        "access": details["access"],
        "pdf_file": details["pdf_file"]
    }

# Example usage:
if __name__ == "__main__":
    # Set `use_parallel=True` to fetch article details in parallel (optional).
    run_extraction(use_parallel=False)
