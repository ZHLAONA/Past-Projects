import os, time, requests, shutil, io, tarfile, urllib.parse
from bs4 import BeautifulSoup
from config import PDF_DIR
from utils import sanitize_filename
import xml.etree.ElementTree as ET

def download_pdf_direct(url, filename, retries=3):
    os.makedirs(PDF_DIR, exist_ok=True)
    tmp_path = os.path.join(PDF_DIR, filename + ".tmp")
    final_path = os.path.join(PDF_DIR, filename)
    attempts = 0

    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/122.0.0.0 Safari/537.36"),
        "Referer": url
    }

    while attempts < retries:
        try:
            r = requests.get(url, stream=True, timeout=15, headers=headers, allow_redirects=True)
            content_type = r.headers.get("content-type", "").lower()

            if "application/pdf" in content_type:
                with open(tmp_path, "wb") as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)
                if os.path.getsize(tmp_path):
                    os.replace(tmp_path, final_path)
                    print(f"Downloaded PDF to {final_path}")
                    return final_path
                else:
                    print(f"Empty file from {url}, retrying…")

            elif content_type.startswith("text/html"):
                soup = BeautifulSoup(r.text, "html.parser")

                meta = soup.find("meta", attrs={"http-equiv": lambda v: v and v.lower() == "refresh"})
                if meta and "url=" in meta.get("content", "").lower():
                    url = requests.compat.urljoin(url, meta["content"].split("=", 1)[1].strip())
                    print("Following meta-refresh →", url)
                    time.sleep(1)
                    continue

                meta = soup.find("meta", attrs={"name": "citation_pdf_url"})
                if meta and meta.get("content"):
                    url = requests.compat.urljoin(url, meta["content"])
                    print("Following citation_pdf_url →", url)
                    time.sleep(1)
                    continue

                link = soup.find("a", href=lambda h: h and ".pdf" in h.lower())
                if link:
                    url = requests.compat.urljoin(url, link["href"])
                    print("Following PDF link →", url)
                    time.sleep(1)
                    continue

                print(f"No PDF link inside wrapper from {url}")

            else:
                print(f"Unexpected content-type '{content_type}', retrying…")

        except Exception as e:
            print(f"Error downloading PDF (attempt {attempts+1}) from {url}: {e}")

        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        attempts += 1
        time.sleep(2)

    print(f"Failed to download PDF from {url} after {retries} attempts.")
    return None

def download_pmc_pdf(pmcid, new_filename=None):
    if new_filename is None:
        new_filename = sanitize_filename(pmcid) + ".pdf"
    return download_pmc_pdf_oa(pmcid, new_filename)

def download_pmc_pdf_oa(pmcid, filename):
    oa_url = f"https://www.ncbi.nlm.nih.gov/pmc/utils/oa/oa.fcgi?id={pmcid}"
    try:
        root = ET.fromstring(requests.get(oa_url, timeout=15).text)
    except Exception as e:
        print(f"OA API failed for {pmcid}: {e}")
        return None

    link = root.find(".//record/link[@format='pdf']")
    if link is not None:
        return _stream_pmc_pdf(link.attrib["href"], filename)

    tgz = root.find(".//record/link[@format='tgz']")
    if tgz is None:
        return None

    tgz_url = tgz.attrib["href"]
    if tgz_url.startswith("ftp://"):
        tgz_url = tgz_url.replace("ftp://", "https://", 1)
    buf = io.BytesIO(requests.get(tgz_url, timeout=30).content)

    with tarfile.open(fileobj=buf, mode="r:gz") as tar:
        member = next((m for m in tar.getmembers() if m.name.lower().endswith(".pdf")), None)
        if member:
            with tar.extractfile(member) as pdf_file:
                return _save_stream(pdf_file, filename)
    return None

def _stream_pmc_pdf(url, filename):
    if url.startswith("ftp://"):
        url = url.replace("ftp://", "https://", 1)
    r = requests.get(url, stream=True, timeout=30)
    if r.status_code == 200 and r.headers.get("content-type", "").startswith("application/pdf"):
        return _save_stream(r.raw, filename)
    return None

def _save_stream(stream, filename):
    os.makedirs(PDF_DIR, exist_ok=True)
    path = os.path.join(PDF_DIR, filename)
    with open(path, "wb") as f:
        shutil.copyfileobj(stream, f)
    print(f"Downloaded → {path}")
    return path

def attempt_pdf_download(details, new_filename=None):
    link = details.get("fulltext_link", "")
    pmcid = details.get("pmcid", "")

    # ✅ Try direct link if it includes "pdf"
    if link and "pdf" in link.lower():
        fname = new_filename or f"{sanitize_filename(details['pubmed_id'])}.pdf"
        return download_pdf_direct(link, fname) or "Not downloaded"

    # ✅ Only proceed with PMC if pmcid is valid and not "No PMC ID"
    elif pmcid and pmcid != "No PMC ID" and pmcid.startswith("PMC"):
        fname = new_filename or f"{sanitize_filename(pmcid)}.pdf"
        return download_pmc_pdf(pmcid, fname) or "Not downloaded"

    # ✅ If nothing valid, skip download
    else:
        print(f"⚠️ Skipping download — No valid fulltext link or PMCID for PubMed ID {details.get('pubmed_id')}")
        return "Not available"


