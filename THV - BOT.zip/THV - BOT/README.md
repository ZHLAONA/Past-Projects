# PubMed Article Scraper & Analyzer

This project automates the process of searching PubMed articles using keywords, downloading open-access PDFs, extracting text, storing data in MongoDB, and presenting results in a web UI.

---

## 🛠 Requirements

- Python 3.8+
- MongoDB installed and running locally
- Chrome (for manual verification of PDFs if needed)

---

## 📦 Setup Instructions

1. **Clone or unzip the project**
2. **Create a virtual environment** (recommended)

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

3. **Install dependencies**

```bash
pip install -r requirements.txt
```

4. **Ensure MongoDB is running locally**  
   You can start it with:
```bash
mongod
```

5. **Run the main script**

```bash
python SciCom.py
```

This will start the scraping and processing pipeline.

---

## 📁 Folder Structure

```
Capstone/
├── data/
│   ├── abbreviations.csv
│   └── keywords.csv
├── pdfs/
├── citations/
├── SciCom.py
├── config.py
├── db_utils.py
├── pubmed_utils.py
├── requirements.txt
```
SciCom.py:- Main logic or controller file for the scientific communication bot workflow. Run this, and the webscraper starts its work

abbrev_utils.py:- Handles logic related to abbreviation processing and expansion for article titles or keywords.

app.py:- Flask app file that runs the web application (UI & backend routing).

config.py:- Stores constants and configuration values (e.g., Mongo URI, file paths, API keys).

db_utils.py:- Functions to connect and interact with MongoDB — insertions, queries, and updates.

fix_webscraped_dates.py:- cleans or standardizes dates from scraped content.

pdf_text_utils.py:- Extracts and processes text from PDF articles using PyPDF2.

pdf_utils.py:- Handles downloading, saving, or validating PDF files (including PubMed links).

pubmed_utils.py:- Handles scraping/searching metadata or article information from PubMed.

setup_text_index.py:- Sets up MongoDB text indexes for efficiently searching through article content.

tag_utils.py:- Processes and manages tags or keywords (possibly uses YAKE).

utils.py:- General utility functions used across multiple scripts (e.g., filename cleaning, time handling).
---

## ✅ Output

- Extracted PDFs saved in `pdfs/`
- Metadata and article text stored in MongoDB
- Citations saved in the `citations/` folder

---

For any issues, make sure your MongoDB is active and the Python version matches.